import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { VideoShowcaseItem } from '../types';
import { X, Volume2, VolumeX, Play, Pause, Maximize, CheckCircle2, MessageSquareQuote, ArrowRight } from 'lucide-react';

interface VideoModalProps {
  video: VideoShowcaseItem | null;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ video, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState('0:00');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === ' ' && videoRef.current) {
        e.preventDefault();
        togglePlay();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  useEffect(() => {
    if (video && videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {
        setIsPlaying(false);
      });
      setIsPlaying(true);
    }
  }, [video]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const current = videoRef.current.currentTime;
    const duration = videoRef.current.duration || 1;
    setProgress((current / duration) * 100);

    const mins = Math.floor(current / 60);
    const secs = Math.floor(current % 60);
    setCurrentTime(`${mins}:${secs < 10 ? '0' : ''}${secs}`);
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!videoRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    videoRef.current.currentTime = pos * (videoRef.current.duration || 0);
  };

  const handleFullScreen = () => {
    if (!videoRef.current) return;
    if (videoRef.current.requestFullscreen) {
      videoRef.current.requestFullscreen();
    }
  };

  return (
    <AnimatePresence>
      {video && (
        <div
          id="video-showcase-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-8 bg-black/90 backdrop-blur-md overflow-y-auto"
          onClick={onClose}
        >
          <motion.div
            id="video-showcase-modal-container"
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-4xl bg-[#131313] border border-[#cda665]/40 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row my-auto max-h-[92vh] overflow-y-auto md:overflow-y-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              id="close-video-modal-btn"
              onClick={onClose}
              className="absolute top-3 right-3 sm:top-4 sm:right-4 z-30 p-2.5 rounded-full bg-[#1b1b1b]/90 border border-[#38332a] text-[#dfc187] hover:text-[#f1ecd9] transition-all duration-200 hover:scale-105"
              aria-label="Close modal"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            {/* Video Player Column */}
            <div className="relative flex-1 bg-[#0d0d0d] flex items-center justify-center min-h-[260px] sm:min-h-[380px] md:min-h-[440px] max-h-[580px] overflow-hidden group shrink-0">
              <video
                ref={videoRef}
                src={video.videoUrl}
                poster={video.posterUrl}
                className="w-full h-full object-contain"
                loop
                playsInline
                muted={isMuted}
                onTimeUpdate={handleTimeUpdate}
                onClick={togglePlay}
              />

              {/* Center Play Overlay Indicator when Paused */}
              {!isPlaying && (
                <div
                  onClick={togglePlay}
                  className="absolute inset-0 flex items-center justify-center bg-black/50 cursor-pointer"
                >
                  <div className="w-16 h-16 rounded-full btn-luxury-gold flex items-center justify-center text-[#14120c] shadow-[0_0_30px_rgba(205,166,101,0.5)] transform transition-transform hover:scale-110">
                    <Play className="w-7 h-7 ml-1 fill-[#14120c]" />
                  </div>
                </div>
              )}

              {/* Video Player Custom Control Bar */}
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#0d0d0d]/95 via-[#0d0d0d]/60 to-transparent p-4 flex flex-col gap-2 opacity-95 group-hover:opacity-100 transition-opacity">
                {/* Scrub Progress Bar */}
                <div
                  className="w-full h-1.5 bg-[#2b2720] rounded-full cursor-pointer overflow-hidden relative"
                  onClick={handleSeek}
                >
                  <div
                    className="h-full bg-gradient-to-r from-[#dfc187] to-[#cda665] transition-all"
                    style={{ width: `${progress}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-xs text-[#f1ecd9]">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={togglePlay}
                      className="p-1.5 rounded-full bg-[#1b1a18] border border-[#38332a] text-[#dfc187] hover:text-[#f1ecd9] transition-colors"
                      aria-label={isPlaying ? 'Pause' : 'Play'}
                    >
                      {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                    </button>
                    <button
                      onClick={toggleMute}
                      className="p-1.5 rounded-full bg-[#1b1a18] border border-[#38332a] text-[#dfc187] hover:text-[#f1ecd9] transition-colors"
                      aria-label={isMuted ? 'Unmute' : 'Mute'}
                    >
                      {isMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-[#dfc187]" />}
                    </button>
                    <span className="font-mono text-[11px] text-[#dfc187]/80">{currentTime}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="px-3 py-0.5 bg-[#181715] border border-[#cda665]/40 rounded-full text-[#dfc187] text-[10px] font-bold uppercase tracking-wider">
                      {video.metric}
                    </span>
                    <button
                      onClick={handleFullScreen}
                      className="p-1.5 rounded-full bg-[#1b1a18] border border-[#38332a] text-[#dfc187] hover:text-[#f1ecd9] transition-colors"
                      aria-label="Fullscreen"
                    >
                      <Maximize className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Video Case Brief / Information Side Panel */}
            <div className="w-full md:w-80 lg:w-96 p-6 md:p-8 flex flex-col justify-between bg-[#141414] border-t md:border-t-0 md:border-l border-[#2b2720] overflow-y-auto">
              <div>
                <div className="badge-luxury-pill mb-3">
                  <MessageSquareQuote className="w-3.5 h-3.5 text-[#dfc187]" />
                  <span>{video.category}</span>
                </div>

                <h3 className="text-xl font-bold font-heading uppercase text-[#f1ecd9] mb-2 leading-snug">
                  {video.title}
                </h3>

                <div className="pb-3 mb-4 border-b border-[#2b2720]">
                  <p className="text-sm font-bold text-[#f1ecd9]">{video.clientName}</p>
                  <p className="font-serif italic text-xs text-[#dfc187]">{video.clientRole}</p>
                </div>

                <p className="text-xs sm:text-sm text-[#f1ecd9]/85 leading-relaxed mb-5">
                  {video.description}
                </p>

                {/* Highlights */}
                <div className="space-y-2 mb-6">
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#dfc187] font-bold block">
                    Execution Highlights
                  </span>
                  {video.highlights.map((item, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-[#f1ecd9]/90">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#cda665] shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Direct WhatsApp Call to Action for this style */}
              <a
                href={`https://wa.me/916303055195?text=Hello%20Flash%20Creator%20Hub,%20I'm%20interested%20in%20creating%20content%20like%20${encodeURIComponent(video.title)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-luxury-gold w-full py-3.5 px-4 text-xs font-bold uppercase tracking-wider font-heading flex items-center justify-center gap-2 shadow-lg"
              >
                <span>Request Similar Production</span>
                <ArrowRight className="w-4 h-4 text-[#14120c]" />
              </a>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
